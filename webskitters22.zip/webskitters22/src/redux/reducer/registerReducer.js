
// import {FETCH_login_SUCCESS,} from '../action/loginAction'

const initialState = {

  loading:false,
  show_form2:false,
 
  firstname   :   '',
  lastname    :   '',
  email       :   '',
  password    :   '',
  conpassword :   '',
  phone       :   '',
 
  city         :   '',
  pincode     :   '', 
  submitted   :   false,
  submitted2   :   false,

  error: null,

  
 
};

export default (state = initialState, action) => {
  switch(action.type) {

    case 'Load_register_first_form':
      return {
        ...state,
      
       loading:false,
       show_form2:true,
       error: null,
      
      };
   

      case 'On_change_handle':
      return {
        ...state,
      
       loading:false,
       [action.payload.target.name] : action.payload.target.value
      };

      case 'Submitted_first_form_validation':
      return {
        ...state,
             submitted:true,     
      };
      case 'Submitted_first_form_validation2':
        return {
          ...state,
               submitted2:true,     
        };
        case 'Second_form_open':
          return {
            ...state,
            show_form2:true,     
          };

          case 'initial_State_blank':
          return {
            ...state,
           
            loading: false,
            show_form2: false,

            firstname: '',
            lastname: '',
            email: '',
            password: '',
            conpassword: '',
            phone: '',

            city: '',
            pincode: '',
            submitted: false,
            submitted2: false,

            error: null,   
          };

          case 'Back_first_form':
        return {
          ...state,
          show_form2:false,     
        };

     

      default:
      // ALWAYS have a default case in a reducer
      return state;
  }
}
