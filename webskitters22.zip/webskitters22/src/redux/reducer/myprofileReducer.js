
// import {FETCH_login_SUCCESS,} from '../action/loginAction'

const initialState = {

  loading:false,
  userdetails: [],
  error: null,

  
 
};

export default (state = initialState, action) => {
  switch(action.type) {

    case 'GET_MY_PROFILE_BEGIN':
      return {
        ...state,
      
       loading:false,
       error: null,
       userdetails: []
      };
   

      case 'GET_MY_PROFILE_SUCCESS':
      return {
        ...state,
      
       loading:true,
       userdetails: action.payload
      };

      case 'GET_MY_PROFILE_UPDATE_SUCCESS':
        return {
          ...state,
        
         loading:true,
         userdetails: action.payload
        };

      case 'GET_MY_PROFILE_FAIL':
        return {
          ...state,
          
          error: action.payload,
          userdetails: []
        };

      default:
      // ALWAYS have a default case in a reducer
      return state;
  }
}
