import { toast } from 'react-toastify';

export function showSuccess(message){
    toast.success(message);
    window.scrollTo(0, 0);
}
export function showError(message){
    toast.error(message);
    window.scrollTo(0, 0);
}
export function showWarning(message){
    toast.warning(message);
    window.scrollTo(0, 0);
}
export function scrollToTop(){
    window.scrollTo(0, 0);
}
export function goBack(){
    setTimeout(function(){ window.history.back() }, 5000);    
}

export function expire_gorgotpassword_token(){
    setTimeout(function(){ window.localStorage.removeItem('forgot_password_token'); }, 600000);    
}