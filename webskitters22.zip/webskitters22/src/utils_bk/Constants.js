export const dotenv                 =   require("dotenv");
export const envpath                =   process.env;
export const SLASH                  =   '/';

export const BASEURL                =   envpath.REACT_APP_APIHOSTURL;
export const IMAGEPATH              =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_IMAGEPATH;

export const bannerAPI              =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_BANNERAPI;
export const popularAPI             =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_POPULARIMG;
export const blockbusterAPI         =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_BLOCKBUSTERIMG;
export const registerAPI            =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_REGISTERAPI;
export const loginAPI               =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_LOGINAPI;
export const playdataAPI            =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_PLAYDATAAPI;
export const forgotpasswordAPI      =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_FORGOTPASSWORD;
export const resetpasswordAPI       =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_RESETPASSWORD;
export const subscriptionlistAPI    =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_SUBSCRIPTIONLIST;
export const my_profileAPI          =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_MY_PROFILE;
export const update_my_profile_info_API      =   envpath.REACT_APP_APIHOSTURL+envpath.REACT_APP_UPDATE_MY_PROFILE_INFO;