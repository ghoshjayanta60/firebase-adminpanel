import LocalizedStrings from 'react-localization';

//Local container:
export const stringsLocalContainer = new LocalizedStrings({
    en: {
        SITE_TITLE          :       "Celebrity Production",
        FACEBOOK_URL        :       "https://www.facebook.com/celebrityproductionbd/",
        TWITTER_URL         :       "https://twitter.com",
    }
});