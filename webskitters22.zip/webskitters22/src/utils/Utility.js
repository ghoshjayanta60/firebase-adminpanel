import { toast } from 'react-toastify';
import axios from 'axios';

export function showSuccess(message){
    toast.success(message);
    window.scrollTo(0, 0);
}
export function showError(message){
    toast.error(message);
    window.scrollTo(0, 0);
}
export function showWarning(message){
    toast.warning(message);
    window.scrollTo(0, 0);
}
export function scrollToTop(){
    window.scrollTo(0, 0);
}
export function goBack(){
    setTimeout(function(){ window.history.back() }, 5000);    
}
export function validateEmail(email){
    if(!/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(email)){
        return true;
    }
}
export function validatePhone(phone){
    //eslint-disable-next-line
    var validatePhone = /^(1\s|1|)?((\(\d{3}\))|\d{3})(\-|\s)?(\d{3})(\-|\s)?(\d{4})$/.test(phone);
    return validatePhone;
}
export function validateDate(date){
    let isValidDate = Date.parse(date);
    if (isNaN(isValidDate)){
        return true;
    }
}
export function expire_gorgotpassword_token(){
    setTimeout(function(){ window.localStorage.removeItem('forgot_password_token'); }, 600000);    
}
 const URL = 'https://dev.solutionsfinder.co.uk/ottdev/Api/';
export function axios_server_call(config){
    
   
      //interceptors handle network error
      axios.interceptors.response.use(
        (response) => {
          return response;
        },
        function (error) {
          if (!error.response) {
            error.response = {
              data: 'net work error',
              status: 500
            }
          }
          if(error.response.status===401){
           // Auth.logout()
           // jumpTo('/login')
            throw error
          }
          return Promise.reject(error);
        });
      config.baseURL = URL
      return axios(config)

}