import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';

import Login from './components/Login';
import Register from './components/Register';
import Profile from './components/Login/Profile';
import {PrivateRoute} from './PrivateRoute';
import {Switch, Route } from 'react-router-dom';

class Router extends React.Component {
 

  constructor(props) {
    super(props)
    this.state = {
        subscribtion_validity: ''
    

    };
}



  componentDidMount() {
  //  this.subscribtion_validity_check()
  }





  render() {

  

  return (
    <div>
        <Header/>
          <Switch>
            {/* <Route  path="/" exact  component={Home} /> */}
            <Route path="/" exact  component={Login} />
            <PrivateRoute path="/register"  component={Register} />
           <PrivateRoute path="/profile"  component={Profile} />  
          </Switch>
        <Footer/>
    </div>
   );
  }
}

export default Router;
