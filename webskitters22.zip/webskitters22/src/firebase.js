import firebase from "firebase";
import "firebase/storage";
// import Header from './components/Header';firebase

  var firebaseConfig = {
    apiKey: "AIzaSyD6o2Wm6qh6PmxOUE_WYzPQnOOM5PfTAt0",
    authDomain: "crud-admin-4bb1d.firebaseapp.com",
    databaseURL: "https://crud-admin-4bb1d-default-rtdb.firebaseio.com",
    projectId: "crud-admin-4bb1d",
    storageBucket: "crud-admin-4bb1d.appspot.com",
    messagingSenderId: "330111496286",
    appId: "1:330111496286:web:81d4258e703664894a44cf"
  };
  // Initialize Firebase
  var fireDb = firebase.initializeApp(firebaseConfig);
 /*export mmyfirebase;
 var fireDb=mmyfirebase.database().ref();
  
 export default fireDb;*/
 

  export default fireDb.database().ref();

// export default firebase;
