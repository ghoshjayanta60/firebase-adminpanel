import React, { Component } from 'react';
// import * as utility from "../../utils/Utility";
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import {
    Container,
    Row,
    Col,
    Nav,
    Collapse,
    Navbar,
    NavbarToggler
} from 'reactstrap';

import { withRouter } from 'react-router-dom';

class Headerlogin extends Component {


    constructor(props) {
        super(props);
        this.state = {
            search_video: '',
            videolist: [],
        }

    }

    /* ---------------start--------------------------*/
    //  search video   start

    // subscribtion validity check
    subscribtion_validity_check = (video_id) => {

        const axios = require('axios');
        const FormData = require('form-data');
        const user_subscriptiondata = new FormData();

        user_subscriptiondata.append('video_id', video_id);
        user_subscriptiondata.append('user_id', localStorage.getItem('user_authenticationid'));


        var user_subscription_config = {
            method: 'post',
            url: 'https://www.itheatre.co/ottdev/Api/get_subscription_status_validity_chk',
            headers: {
                'Content-Type': 'application/json'
            },
            data: user_subscriptiondata

        };

        axios(user_subscription_config)
            .then(function (response) {
                console.log(response.data);

                if (response.data.status === 'free') {
                    localStorage.setItem('valid_status', 'valid');
                    this.props.history.push('/play/' + video_id);

                }

               else if (response.data.status === 'valid') {
                    localStorage.setItem('valid_status', 'valid');
                    this.props.history.push('/play/' + video_id);

                }
                else if (response.data.status === 'not_subscribe') {
                    localStorage.setItem('valid_status', '');
                    alert('Your new account have not added any subscription.Purchase a new subscription.')
                  // utility.showError(response.data.message);
                    this.props.history.push('/dashboard');

                }

                else {
                    localStorage.setItem('valid_status', '');
                    alert('Your Subscription Package is Expired choose your next plan')
                //  utility.showError(response.data.message);
                    this.props.history.push('/dashboard');

                }

            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });


    }

    // search by video name & category

    search_by_video_name_cat = () => {

        const axios = require('axios');
        const FormData = require('form-data');
        const search_data = new FormData();

        console.log(this.state.search_video)

        search_data.append('search_key', this.state.search_video);


        var user_subscription_config = {
            method: 'post',
            url: 'https://www.itheatre.co/ottdev/Api/search_content',
            headers: {
                'Content-Type': 'application/json'
            },
            data: search_data

        };

        axios(user_subscription_config)
            .then(function (response) {
                //   console.log(response.data);
                if(response.data.status==='success'){
                    this.setState({
                        videolist: response.data.search_result
                    })

                }else{
                    this.setState({
                        videolist: []
                    })

                }
                
            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });

    }

    handleonChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
        //  this.search_by_video_name_cat();
    }

    
    // Show more result page
    show_more_result_page=()=>{

        this.setState({
            videolist: []
        })
 
        this.props.history.push(`/videolist/${this.state.search_video}`);
    }


    componentWillReceiveProps(nextProps) {

        console.log(this.props.location)
        console.log(nextProps.location)
       
        if (nextProps.location !== this.props.location) {
        
         this.setState({
                       videolist: []
                       }) 

        }
      }

    // componentWillUpdate(np) {


    //    console.log(window.location.href) 
    //    const previewurl = window.location.href
    //    console.log(previewurl)
    //   const previewurlarr= previewurl.split('/')
    //   console.log(previewurlarr[3])

    //           const nexturl = np.match.url
    //       const nexturlarr= nexturl.split('/')
    //       console.log(nexturlarr[1])

    //       if(nexturlarr[1] && previewurlarr[3] !== nexturlarr[1]){
    //                 // do something
              
    //                    this.setState({
    //                       videolist: []
    //                    }) 
                   
                  
    //             }




        //   const previewurl=window.location.href
        //   const { match } = this.props
        //   if(match){

        //     const previewurl = window.location.href
        //     console.log(previewurl)
        //    const previewurlarr= previewurl.split('/')
        //    console.log(previewurlarr[1])

        //   }
         
         
      
      
          
    //       if(nexnp.match.urlturl){
    //         const nexturl = np.match.url
    //       const nexturlarr= nexturl.split('/')
    //       console.log(nexturl)
        
    //       }

    //       if(match && nexturl ){
    //       if(nexturlarr[1] && previewurlarr[1] !== nexturlarr[1]){
    //         // do something
      
    //            this.setState({
    //               videolist: []
    //            }) 
           
          
    //     }
    //  }
   









    // search video end

    /* ---------------end--------------------------*/




    log_out = () => {
        //  alert('ok');
        this.props.dispatch({
            type: 'FETCH_LOGOUT_SUCCESS',
            payload: []
        });
        localStorage.clear();
        this.props.history.push(`/`);

    }

    log_in_page = () => {

        this.props.history.push(`/`);
    }

    render() {


        let output = null;

        if (localStorage.getItem('user_authenticationid')) {
            output =
                (

                    <>
                        <Col md="4" sm="6">
                            <div className="sign-in">
                                <Link to="#" onClick={() => this.log_out()}>Sign out</Link>
                            </div>
                        </Col>
                    </>


                );
        }

        else {
            output = (

                <>
                    <Col md="4" sm="6">
                        <div className="sign-in">
                            {/* <Link onClick={()=>this.log_in_page()} >Sign in</Link> */}
                            <Link to="/" >Sign in</Link>
                        </div>
                    </Col>
                </>


            )

        }



     /* ---------------start--------------------------*/

        const { videolist } = this.state

        let showsearchItem = [];

        const show_search_result = () => {

            if (videolist.length>0) {

                for (let i = 0; i < videolist.slice(0, 1).length; i++) {
                    showsearchItem.push(

                        <Link to="#" onClick={() => this.subscribtion_validity_check(videolist[i].video_id)} className="item" key={'video_result'+i}>
                            <img src={videolist[i].mobile_poster_image} alt={videolist[i].video_title} style={{ width: '200px', height: '200px' }} />
                            <span>{videolist[i].video_title}</span>

                        </Link>

                    );
                }
                if (videolist) {
                showsearchItem.push(<button key={'more_result'} onClick={()=>this.show_more_result_page()} >More results</button>);
                }
            }
            else {
                if (!videolist) {
                showsearchItem.push(<h1 key={'no_result'}>No Result Found .....</h1>);
                }

            }

            return showsearchItem;
        };


      /* --------------- end --------------------------*/





        return (
            <header>
                <div className="header-top">
                    <Container>
                        <Row>
                            <Col md="3" sm="4" className="logo">
                                <Link to="/">
                                    <img src={require('../../assets/images/logo.png')} alt="logo" className="img-responsive" />
                                </Link>
                            </Col>
                            <Col md="5" sm="8" className="nav-css">
                                <Navbar light expand="md" className="navbar navbar-default">
                                    <NavbarToggler type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false" />
                                    <Collapse navbar>
                                       
                                    </Collapse>
                                </Navbar>
                                <Nav className="navbar navbar-default">
                                    <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                        <ul className="nav navbar-nav">
                                            <li className="active"><Link className="nav-link" to="/">Home</Link></li>
                                            <li><Link className="nav-link" to="/shows">Shows</Link></li>
                                            <li><Link className="nav-link" to="/movie">Movie</Link></li>
                                            <li><Link className="nav-link" to="/plan">Plan</Link></li>
                                            <li><Link className="nav-link" to="/free">Free</Link></li>
                                        </ul>
                                    </div>
                                </Nav>
                            </Col>


                            {/* search   list*/}

                          


                            {/* { this.state.videolist  ?
                                ( 
                                     this.state.videolist.slice(0, 1).map((val,inc) =>
                                     <>
                                        <Link to="#" onClick={()=>this.subscribtion_validity_check(val.video_id)} className="item" key={inc}>
                                            <img src={val.mobile_poster_image} alt={val.video_title} style={{width:'200px',height:'200px'}} />
                                            <span>{val.video_title}</span>
                                            
                                        </Link> 
                                      
                                        </>
                                       
                                        
                                    ) 
                                    
                                    
                                  
                                  
                                 
                                 ) :(<h1>No Result Found .....</h1>)
                            } */}



                            {show_search_result()}



                            {/* search   list*/}









                            {output}





                        </Row>
                    </Container>
                </div>
            </header>
        );
    }
}

const mapStateToProps = state => ({
    authenticationid: state.loginReducer.authenticationid


});

export default connect(mapStateToProps)(withRouter(Headerlogin));

