import React, { Component }  from 'react';
import {Helmet} from "react-helmet";
import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { Link } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
// import {loginAPI, googleAPI} from '../../utils/Constants';
//redux
// import FacebookLogin from 'react-facebook-login';
import { FacebookProvider, Login } from 'react-facebook';
import { GoogleLogin } from 'react-google-login';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

class LoginForm extends Component{
    constructor(props) {
        super(props)
        this.state = {
            email       :   '',
            password    :   '',

            facebookuserID      :   '',
            facebookname        :   '',
            facebookemail       :   '',
            facebookpicture     :   '',
            facebookphone       :   '',

            googlename          :   '',
            googleemail         :   '',
            googlepicture       :   ''
        };
    }
    initialState = () => {
        this.setState({
        email       :   '',
        password    :   '',
        submitted   :   false
        })
    }
    handleChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }
    onSubmit = (e) => {
        e.preventDefault();
        this.setState({ submitted: true });
        if(!this.state.email && !this.state.password){
            utility.showError("Please Enter Email or Phone & Password");
            return false;
        }
        if(!this.state.email){
            utility.showError("Please Enter Email or Phone");
            return false;
        }
        if(!this.state.password){
            utility.showError("Please Enter Password");
            return false;
        }
        const axios     =   require('axios');
        const FormData  =   require('form-data');
        const data      =   new FormData();

        data.append('username', this.state.email);
        data.append('password', this.state.password);

        var config  =   {
            method  :   'post',
            url     :   'loginAPI',
            headers :   {
                'Content-Type': 'application/json'
            },
            data : data
        };

        axios(config)
            .then(function (response){
            if(response.data.status === 'success'){
                this.props.dispatch({
                    type        :   'FETCH_LOGIN_SUCCESS',
                    payload     :   response
                });
                this.initialState();
                utility.showSuccess(response.data.message);
                localStorage.setItem('user_authenticationid', response.data.userdata.user_id);
                this.props.history.push('/dashboard');
            }
            else if(response.data.status === 'warning'){
                utility.showWarning(response.data.message); 
            }
            else{
                utility.showError(response.data.message); 
            }            
        }.bind(this))
            .catch(function (error){
            // console.log(error);
        });        
    }

    responseFacebook = (response) => {
        console.log(response);
        /*this.setState({
            facebookuserID  :   response.userID,
            facebookname    :   response.name,
            facebookemail   :   response.email,
            facebookphone   :   response.phone,
            facebookpicture :   response.picture.data.url
        })*/
    }

    responseGoogle = (response) => {
        // console.log(response);
        if(response.profileObj !== undefined){
            this.setState({
                // googleuserID:response.userID,
                firstName       :   response.profileObj.givenName,
                lastName        :   response.profileObj.familyName,
                email           :   response.profileObj.email,
                googleToken     :   response.profileObj.googleId
            })

            var axios       =   require('axios');
            var FormData    =   require('form-data');
            var data        =   new FormData();
            
            data.append('firstName', response.profileObj.givenName);
            data.append('lastName', response.profileObj.familyName);
            data.append('email', response.profileObj.email);        
            data.append('googleToken', response.profileObj.googleId);

            var config  =   {
                method  :   'post',
                url     :   'googleAPI',
                headers :   {
                    'Content-Type': 'application/json'
                },
                data : data
            };

            axios(config)
                .then(function (response){
                if(response.data.status === 'success'){
                    this.props.dispatch({
                        type        :   'FETCH_LOGIN_SUCCESS',
                        payload     :   response
                    });
                    this.initialState();
                    utility.showSuccess(response.data.message);
                    localStorage.setItem('user_authenticationid', response.data.userdata.user_id);
                    this.props.history.push('/dashboard');
                }
                else if(response.data.status === 'warning'){
                    utility.showWarning(response.data.message); 
                }
                else{
                    utility.showError(response.data.message); 
                }            
            }.bind(this))
                .catch(function (error){
                // console.log(error);
            });
        }
    }

    componentClicked = () => {
        //console.log('Clicked');
    }

    handleResponse = (response) => {
        console.log(response);
        this.setState({
            facebookuserID:response.profile.id,
            facebookname:response.profile.name,
            facebookemail:response.profile.email,
            facebookphone:response.profile.phone,
            facebookpicture:response.profile.picture.data.url
        })
    }
     
    handleError = (error) => {
        this.setState({ error });
    }

    async componentDidMount(){window.scrollTo(0,0);}
    render(){
        const { email, password, submitted } = this.state;
        return(
            <div className="contain-area">
                <Helmet>
                    <title>Login | {strings.stringsLocalContainer.SITE_TITLE}</title>
                </Helmet>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="panel panel-default login-area1">                            
                                <div className="panel-body">
                                <div className="panel-heading">
                                    <h3 className="panel-title">Login</h3>
                                </div>
                                <form method="post">
                                    <fieldset>
                                    <div className={'input-name' + (submitted && !email ? ' has-error' : '')}>
                                        <input value={email} placeholder="Mobile / Email Address" name="email" type="text" onChange={e => this.handleChange(e)} required />
                                        <span className="underline-animation"></span>
                                    </div>
                                    <div className={'input-name' + (submitted && !password ? ' has-error' : '')}>
                                        <input value={password} placeholder="Password" name="password" type="password" onChange={e => this.handleChange(e)} required />
                                        <span className="underline-animation"></span>
                                    </div>
                                    <div className="checkbox1">
                                        <label> Don't have an account? <Link to="/register">Create one</Link> </label>
                                    </div>
                                    <input onClick={(e) => this.onSubmit(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Sign In" />
                                    <div className="checkbox1"> 
                                        <label> <Link to="/forgotpassword">Forget Password ?</Link> </label>
                                    </div>
                                    </fieldset>
                                </form>
                                <div className="line-form"><ToastContainer /></div>
                                <center>
                                    <h4>OR</h4>
                                </center>
                                <div className="login-with">Login With</div>
                                <div className="social-logo">
                                    {/*<Link to="/">
                                        <img src={require('../../assets/images/g-logo.png')} alt="google" />
                                    </Link>*/}
                                    <Link to="/">
                                        <img src={require('../../assets/images/f-logo.png')} alt="facebook" />
                                    </Link>
                                    <GoogleLogin
                                        clientId      =   "270984297857-p82jsv292issqsaqfl23892guthjk2gp.apps.googleusercontent.com"
                                      //  clientId      =   {GOOGLEAPIKEY}
                                        buttonText    =   "Login"
                                        onSuccess     =   {this.responseGoogle}
                                        onFailure     =   {this.responseGoogle}
                                        cookiePolicy  =   {'single_host_origin'}  />

                                    <FacebookProvider appId="947498789083852">
                                        <Login
                                            scope="email"
                                            fields="name,email,picture"
                                            onCompleted={this.handleResponse}
                                            onError={this.handleError}
                                            >
                                            {({ loading, handleClick, error, data }) => (
                                                <span style={{color:'white'}} onClick={handleClick}>
                                                Login via Facebook
                                                {loading && (
                                                    <span>Loading...</span>
                                                )}
                                                </span>
                                            )}
                                        </Login>
                                </FacebookProvider>
                                    
                                    {/*<FacebookLogin
                                        appId     =   "1086933914786754"
                                        fields    =   "name,email,picture"
                                        callback  =   {this.responseFacebook}
                                    />*/}
                                    {/*<div style={{color:"white"}}> {this.state.googlename}</div>
                                    <div style={{color:"white"}}> {this.state.googleemail}</div>
                                    <div style={{color:"white"}}> {this.state.googlepicture}</div>*/}

                                    <div style={{color:"white"}}> {this.state.facebookuserID}</div>
                                    <div style={{color:"white"}}> {this.state.facebookname}</div>
                                    <div style={{color:"white"}}> {this.state.facebookemail} </div>
                                    <div style={{color:"white"}}> { this.state.facebookphone}</div>
                                    <div style={{color:"white"}}> { this.state.facebookpicture}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="login-area2">
                            <Link to="/">
                                <img src={require('../../assets/images/big-pic.jpg')} alt="poster" className="formImg" />
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        );
    }
}

const mapStateToProps = state => ({
    authenticationid: state
});
export default connect(mapStateToProps)(withRouter(LoginForm));