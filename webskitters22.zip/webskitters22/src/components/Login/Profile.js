import React, { Component } from 'react';
import { Link } from 'react-router-dom';
// import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { ToastContainer } from 'react-toastify';

import { Container, Row, Col,Table } from 'reactstrap';
import { Helmet } from "react-helmet";
import { connect } from 'react-redux';
import fireDb  from "../../firebase";
 import { user_details } from '../../redux/action/myprofileAction'
 import { CSVLink } from "react-csv"

class Profile extends Component {



    constructor(props) {
        super(props)
        this.state = {

        };

        
    }

    componentDidMount() {
        console.log(localStorage.getItem('user_authenticationid'))
       this.props.user_details() 

    }

     delete_user = (id) => {
       // alert(id)

       const todeRef= fireDb.child('contact').child(id);
       todeRef.remove();
       this.props.user_details();
           // console.log(contacts)
          
    }



    
    handleChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }

    render() {
        const {userdetails}=this.props

     const   headers = [
                     { label: "Name", key: "firstname" },
                     { label: "Lastname", key: "lastname" },
                     { label: "Email", key: "email" },
                     { label: "Phone", key: "phone" },
                     { label: "Pincode", key: "pincode" },
                     { label: "City", key: "city" }
                     ];
        
        const csvReport={filename:'Report.csv',headers:headers,data:userdetails}
       

        return (
            <div className="contain-area">
                <Helmet>
                    <title>User List | {strings.stringsLocalContainer.SITE_TITLE}</title>
                </Helmet>
                <Container>
                    <Row>
                        <Col md="12" className="profile-new-div">
                            <div role="tabpanel">
                                <Col sm="3">
                                    <div className="user-img">
                                        {/* <img src={require('../../assets/images/big-pic.jpg')} alt="poster"/> */}
                                        <img src="test"

                                            //  onChange={this.onFileChange}
                                            alt="poster" />
                                        <input type="file"
                                            style={{ display: 'none' }}
                                           
                                        ></input>

                                        <div title="edit" style={{ backgroundColor: 'white', width: '20px' }}  >
                                            <i className="fa fa-pencil-alt" aria-hidden="true"></i>

                                        </div>
                                        {/* <img src={this.state.profile_img} alt="my phonto"></img>
                                        <input type="button" onClick={()=>this.onFileupload()} value="upload"></input> */}
                                    </div>
                                <div className="user-name">Admin </div>
                                <div className="user-name"></div>
                                <div className="user-name"> </div>
                                    <div className="user-sicial">
                                        <i className="fa fa-facebook" aria-hidden="true"></i>
                                        <i className="fa fa-twitter" aria-hidden="true"></i>
                                        <i className="fa fa-youtube-play" aria-hidden="true"></i>
                                        <i className="fa fa-pinterest" aria-hidden="true"></i>
                                    </div>
                                    <ul className="nav nav-pills brand-pills nav-stacked" role="tablist">
                                        <li role="presentation" className="brand-nav active">
                                            <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab"> <i className="fa fa-user" aria-hidden="true"></i> Basic Details</a>
                                        </li>
                                        
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab"> <i className="fa fa-cog" aria-hidden="true"></i> Settings</a>
                                        </li>
                                    </ul>
                                </Col>
                                <Col sm="9" className="tab-desc-area">
                                    <div className="tab-content">
                                      
                                        <div role="tabpanel" className="tab-pane active" id="tab1">
                                            <div className="panel-heading">
                                                <h3 className="panel-title">User List</h3>
                                            </div>
                                            <button onClick={()=>this.props.history.push('/register')}> Add </button>
                                           <CSVLink {...csvReport}> Download Csv </CSVLink>
                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}}>Name</th>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}} >Email</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Phone</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Pincode</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >City</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Action</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    { 

                                                    userdetails && userdetails.map( 
                                                        ( item, key) => 
                                                        
                                                            <tr key={key}>
                                                            <td style={{color:'white'}}>{item.firstname}</td>
                                                            <td style={{color:'white'}}>{item.email}</td>
                                                            <td style={{color:'white'}}>{item.phone} Day</td>
                                                            <td style={{color:'white'}}>{ item.pincode} </td>
                                                            <td style={{color:'white'}}>{ item.city} </td>
                                                            <td style={{color:'white'}}><button onClick={()=>this.delete_user(item.id)}> Delete </button> </td>
                                                           
                                                        </tr>

                                                       )                                            
                                                    }
                                                   

                                                </tbody>
                                            </Table>
                                            <div className="line-form"><ToastContainer /></div>
                                            {/* <center>
                                    <h4>Or</h4>
                                </center> */}
                                        </div>

                                        <div role="tabpanel" className="tab-pane" id="tab2">
                                            <div className="panel-heading">
                                                <h3 className="panel-title">Change Password</h3>
                                            </div>
                                           
                                          

                                            <div className="line-form"><ToastContainer /></div>
                                            {/* <center>
                                    <h4>Or</h4>
                                </center> */}
                                        </div>
                                       
                                       
                                       
                                   



                                    </div>
                                </Col>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}


const mapStateToProps = state => ({
    userdetails: state.myprofile.userdetails
})

const mapDispatchToProps={
    user_details
   }


export default connect(mapStateToProps,mapDispatchToProps)(Profile);
