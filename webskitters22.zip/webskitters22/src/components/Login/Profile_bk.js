import React, { Component } from 'react';
import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { ToastContainer } from 'react-toastify';
import {  my_profileAPI, update_my_profile_info_API, change_passwordAPI, fetch_user_subscription_listAPI, change_profile_picture_API } from '../../utils/Constants';
// import { Link } from 'react-router-dom';
import { Container, Row, Col, Table } from 'reactstrap';
import { Helmet } from "react-helmet";
//import { connect } from 'react-redux';
// import { user_details } from '../../redux/action/myprofileAction'

import ReactPaginate from 'react-paginate';
import './my_pagination.css'

//import Pagination from "react-js-pagination";

// require("../../../../../bootstrap/less/bootstrap.less");

class Profile extends Component {



    constructor(props) {
        super(props)
        this.state = {
            userDetails: [],
            user_subscription_Details: [],
            current_subscription_list:[],
            user_favourits_video_Details: [],
            user_watchlist_video_Details: [],
            username: '',
            email: '',
            phone: '',
            profile_img: null,
            submitted: false,
            password_submitted: false,
          //  activePage: 2,
          //pagination
          offset: 0,
          data: [],
          perPage: 5,
          currentPage: 0

        };

        this.handlePageClick = this
        .handlePageClick
        .bind(this);
    }

    componentDidMount() {
        const axios = require('axios');
        const FormData = require('form-data');
        const myprofiledata = new FormData();

        myprofiledata.append('user_id', localStorage.getItem('user_authenticationid'));


        var my_profile_config = {
            method: 'post',
            url: my_profileAPI,
            headers: {
                'Content-Type': 'application/json'
            },
            data: myprofiledata

        };



        //  this.props.user_details(my_profile_config)

        axios(my_profile_config)
            .then(function (response) {
                console.log(response.data);
                console.log((response.data.my_details.email));
                if (response.data.status === 'success') {

                    this.setState({
                        userDetails: response.data.my_details,
                        username: response.data.my_details.first_name + ' ' + response.data.my_details.last_name,
                        email: response.data.my_details.email,
                        phone: response.data.my_details.phone,
                        //  submitted   :   false

                    });

                }

            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });



            this.user_subscription_list()
            this.user_favourits_video_Details()
            this.user_watchlist_video_Details()



    }

// video details page
    video_details_page=(videoid)=>{
        this.props.history.push(`/play/${videoid}`);
    }

     // user subscription list
    user_subscription_list=()=>{

        const axios = require('axios');
        const FormData = require('form-data');
        const user_subscriptiondata = new FormData();

        user_subscriptiondata.append('user_id', localStorage.getItem('user_authenticationid'));


        var user_subscription_config = {
            method: 'post',
            url: fetch_user_subscription_listAPI,
            headers: {
                'Content-Type': 'application/json'
            },
            data: user_subscriptiondata

        };



        //  this.props.user_details(my_profile_config)

        axios(user_subscription_config)
            .then(function (response) {
                console.log(response.data);
               
                if (response.data.status === 'success') {

                    const my_subscription_list = response.data.subscription_list;
                    const slice = my_subscription_list.slice(this.state.offset, this.state.offset + this.state.perPage)



                    this.setState({
                        pageCount: Math.ceil(my_subscription_list.length / this.state.perPage),
                        user_subscription_Details: slice,
                        current_subscription_list:response.data.current_subscription_list
                        
                    });

                }

            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });

    }

    handlePageClick = (e) => {
        const selectedPage = e.selected;
        const offset = selectedPage * this.state.perPage;

        this.setState({
            currentPage: selectedPage,
            offset: offset
        }, () => {
            this.user_subscription_list()
        });

    };








// user favourits list
    user_favourits_video_Details=()=>{

        const axios = require('axios');
        const FormData = require('form-data');
        const user_favourits_video_data = new FormData();

        user_favourits_video_data.append('userid', localStorage.getItem('user_authenticationid'));


        var user_subscription_config = {
            method: 'post',
            url: 'https://dev.solutionsfinder.co.uk/ottdev/Api/get_favourites_video',
            headers: {
                'Content-Type': 'application/json'
            },
            data: user_favourits_video_data

        };



        //  this.props.user_details(my_profile_config)

        axios(user_subscription_config)
            .then(function (response) {
                console.log(response.data);
               
                if (response.data.status === 'success') {

                    this.setState({
                        user_favourits_video_Details: response.data.favourite_list,
                        
                    });

                }

            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });




    }

    // user watchlist list
    user_watchlist_video_Details=()=>{

        const axios = require('axios');
        const FormData = require('form-data');
        const user_watchlist_video_data = new FormData();

        user_watchlist_video_data.append('userid', localStorage.getItem('user_authenticationid'));


        var user_subscription_config = {
            method: 'post',
            url: 'https://dev.solutionsfinder.co.uk/ottdev/Api/get_favourites_video',
            headers: {
                'Content-Type': 'application/json'
            },
            data: user_watchlist_video_data

        };



        //  this.props.user_details(my_profile_config)

        axios(user_subscription_config)
            .then(function (response) {
                console.log(response.data);
               
                if (response.data.status === 'success') {

                    this.setState({
                        user_watchlist_video_Details: response.data.favourite_list,
                        
                    });

                }

            }.bind(this))
            .catch(function (error) {
                console.log(error);
            });




    }



// profile picture change

    onFileChange = async (e) => {

        // Update the state 
        //  this.setState({ profile_img: event.target.files[0] }); 

        const file = e.target.files[0];
        const baase64 = await this.convertBase64(file)
        //  console.log(baase64)

        this.setState({ profile_img: baase64 })
        this.onFileupload()

    }


    convertBase64 = (file) => {

        return new Promise((resolve, reject) => {
            const fileReader = new FileReader()
            fileReader.readAsDataURL(file);
            fileReader.onload = () => {
                resolve(fileReader.result)
            }
            fileReader.onerror = (error) => {
                reject(error)
            }
        })

        // Update the state 
        //  this.setState({ profile_img: event.target.files[0] }); 

        //  const file= e.target.files[0];
        //  const base64= await convertBase64(file);
        //  console.log(base64)

    }


    onFileupload = () => {
        console.log(this.state.profile_img)

        const encode_image = this.state.profile_img.split(';base64,')

        console.log(encode_image[1])

        // const {Base64} = require('js-base64')  

        // console.log(Base64.encode(this.state.profile_img)) 



        // let bufferObj = Buffer.from(this.state.profile_img, "utf8");

        // Encode the Buffer as a base64 string
        // let base64String = bufferObj.toString("base64");

        // console.log(   new Buffer('this.state.profile_img').toString('base64'));
        const axios = require('axios');
        const FormData = require('form-data');
        const imageformData = new FormData();



        imageformData.append('user_id', localStorage.getItem('user_authenticationid'));
        imageformData.append(
            'profile_img',
            encode_image[1]
            //  this.state.profile_img 



        );


        var image_config = {
            method: 'post',
            url: change_profile_picture_API,
            headers: {
                'Content-Type': 'application/json'
                // 'content-type': 'multipart/form-data'
            },
            data: imageformData
        };

        axios(image_config)
            .then(function (response) {
                //  console.log(JSON.stringify(response.data));
                console.log((response.data));
                if (response.data.status === 'success') {

                    // this.initialState();
                    utility.showSuccess(response.data.status);

                }
                if (response.data.status === 'failed') {

                    // this.initialState();
                    utility.showError(response.data.message);


                }

            })
            .catch(function (error) {
                console.log(error);
            });




    }



    initialState = () => {
        this.setState({
            email: '',
            username: '',
            phone: '',
            submitted: false
        })
    }
    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    // submit profile data
    onSubmit = (e) => {
        e.preventDefault();
        this.setState({ submitted: true });

        var responsename = this.state.username.split(" ")

        //  console.log( localStorage.getItem('user_authenticationid') +' '+this.state.email);


        // console.log(responsename[0]+' '+responsename[1])

        // console.log(this.state.phone +' '+ localStorage.getItem('country_code') +' '+localStorage.getItem('dob'));


        if (!this.state.username && !this.state.email && !this.state.phone) {
            utility.showError("Please Enter all fields");
            return false;
        }
        if (!this.state.username) {
            utility.showError("Please Enter Name");
            return false;
        }
        if (!this.state.email) {
            utility.showError("Please Enter Email");
            return false;
        }

        const atpos = this.state.email.indexOf("@");
        const dotpos = this.state.email.lastIndexOf(".");
        if (atpos < 1 || (dotpos - atpos < 2)) {
            utility.showError("Please enter correct email ID")

            return false;
        }

        if (!utility.validatePhone(this.state.phone)) {
            utility.showError("Please Enter Valid Phone");
            return false;
        }


        const axios = require('axios');
        const FormData = require('form-data');
        const data = new FormData();



        data.append('usrId', localStorage.getItem('user_authenticationid'));
        data.append('email', this.state.email);
        data.append('firstname', responsename[0]);
        data.append('lastname', responsename[1]);
        data.append('phone', this.state.phone);
        data.append('CountryCode', localStorage.getItem('country_code'));
        data.append('dob', localStorage.getItem('dob'));

        var config = {
            method: 'post',
            url: update_my_profile_info_API,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
                //console.log((response.data));
                if (response.data.status === 'success') {

                    // this.initialState();
                    utility.showSuccess(response.data.message);
                    // localStorage.setItem('user_authenticationid', response.data.userdata.user_id);

                    //   this.props.history.push(`/dashboard`);
                }
                else if (response.data.status === 'warning') {
                    utility.showWarning(response.data.message);
                }
                else {
                    utility.showError(response.data.message);
                }
            })
            .catch(function (error) {
                console.log(error);
            });



    }



    onpassword_Submit = (e) => {
        e.preventDefault();
        this.setState({ password_submitted: true });




        if (!this.state.old_password && !this.state.new_password) {
            utility.showError("Please Enter all fields");
            return false;
        }
        if (!this.state.old_password) {
            utility.showError("Please Enter Old Password");
            return false;
        }
        if (!this.state.new_password) {
            utility.showError("Please Enter New Password");
            return false;
        }


        const axios = require('axios');
        const FormData = require('form-data');
        const password_data = new FormData();



        password_data.append('user_id', localStorage.getItem('user_authenticationid'));
        password_data.append('oldpassword', this.state.old_password);

        password_data.append('newpassword', this.state.new_password);

        var config = {
            method: 'post',
            url: change_passwordAPI,
            headers: {
                'Content-Type': 'application/json'
            },
            data: password_data
        };

        axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
                //console.log((response.data));
                if (response.data.status === 'success') {

                    // this.initialState();
                    utility.showSuccess(response.data.message);
                    // localStorage.setItem('user_authenticationid', response.data.userdata.user_id);

                    //   this.props.history.push(`/dashboard`);
                }
                else if (response.data.status === 'warning') {
                    utility.showWarning(response.data.message);
                }
                else {
                    utility.showError(response.data.message);
                }
            })
            .catch(function (error) {
                console.log(error);
            });



    }

// handle page
    // handlePageChange(pageNumber) {
    //     console.log(`active page is ${pageNumber}`);
    //     this.setState({activePage: pageNumber});
    //   }


    render() {
        const { username, email, phone, submitted, password_submitted, old_password, new_password, user_subscription_Details,user_favourits_video_Details,user_watchlist_video_Details,current_subscription_list } = this.state;
        // const {my_details } = this.props.userprofileDetails;
        var months = ["January","February","March","April","May","June","July","August","September","October","November","December"]

        return (
            <div className="contain-area">
                <Helmet>
                    <title>My Profile | {strings.stringsLocalContainer.SITE_TITLE}</title>
                </Helmet>
                <Container>
                    <Row>
                        <Col md="12" className="profile-new-div">
                            <div role="tabpanel">
                                <Col sm="3">
                                    <div className="user-img">
                                        {/* <img src={require('../../assets/images/big-pic.jpg')} alt="poster"/> */}
                                        <img src={this.state.profile_img || this.state.userDetails.profile_img}

                                            //  onChange={this.onFileChange}
                                            alt="poster" />
                                        <input type="file"
                                            style={{ display: 'none' }}
                                            ref={edit_profile_pic => this.edit_profile_pic = edit_profile_pic}
                                            onChange={this.onFileChange}
                                        ></input>

                                        <div title="edit" style={{ backgroundColor: 'white', width: '20px' }} onClick={() => this.edit_profile_pic.click()} >
                                            <i className="fa fa-pencil-alt" aria-hidden="true"></i>

                                        </div>
                                        {/* <img src={this.state.profile_img} alt="my phonto"></img>
                                        <input type="button" onClick={()=>this.onFileupload()} value="upload"></input> */}
                                    </div>
                                    <div className="user-name">{this.state.username}</div>
                                    <div className="user-sicial">
                                        <i className="fa fa-facebook" aria-hidden="true"></i>
                                        <i className="fa fa-twitter" aria-hidden="true"></i>
                                        <i className="fa fa-youtube-play" aria-hidden="true"></i>
                                        <i className="fa fa-pinterest" aria-hidden="true"></i>
                                    </div>
                                    <ul className="nav nav-pills brand-pills nav-stacked" role="tablist">
                                        <li role="presentation" className="brand-nav active">
                                            <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab"> <i className="fa fa-user" aria-hidden="true"></i> Basic Details</a>
                                        </li>
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab"> <i className="fa fa-check-circle-o" aria-hidden="true"></i> Subscriptions</a>
                                        </li>
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab"> <i className="fa fa-heart" aria-hidden="true"></i> Social Life</a>
                                        </li>
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab"> <i className="fa fa-play" aria-hidden="true"></i> Work & Play</a>
                                        </li>
                                        <li role="presentation" className="brand-nav">
                                            <a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab"> <i className="fa fa-cog" aria-hidden="true"></i> Settings</a>
                                        </li>
                                    </ul>
                                </Col>
                                <Col sm="9" className="tab-desc-area">
                                    <div className="tab-content">
                                        <div role="tabpanel" className="tab-pane active" id="tab1">
                                            <div className="panel-heading">
                                                <h3 className="panel-title">Profile</h3>
                                            </div>
                                            <form method="post">
                                                <fieldset>

                                                    <div className={'input-name' + (submitted && !username ? ' has-error' : '')} >
                                                        <input type="Email" value={username} onChange={e => this.handleChange(e)} name="username" placeholder="Name" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    <div className={'input-name' + (submitted && !email ? ' has-error' : '')} >
                                                        <input type="Email" value={email} onChange={e => this.handleChange(e)} name="email" placeholder="Email" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    <div className={'input-name' + (submitted && !phone ? ' has-error' : '')}>
                                                        <input type="tel" value={phone} onChange={e => this.handleChange(e)} name="phone" placeholder="Phone" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <input onClick={(e) => this.onSubmit(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Update" />
                                                </fieldset>
                                            </form>
                                            <div className="line-form"><ToastContainer /></div>
                                            {/* <center>
                                    <h4>Or</h4>
                                </center> */}
                                        </div>
                                        <div role="tabpanel" className="tab-pane" id="tab2">
                                        <div className="panel-heading">
                                                <h3 className="panel-title">Subscription List</h3>
                                            </div>
                                            {/* <p> Zombie ipsum reversus ab viral inferno, nam rick grimes malum cerebro. De carne lumbering animata corpora quaeritis. Summus brains sit, morbo vel maleficia? De apocalypsi gorger omero undead survivor dictum mauris. Hi mindless mortuis soulless creaturas, imo evil stalking monstra adventus resi dentevil vultus comedat cerebella viventium. Qui animated corpse, cricket bat max brucks terribilem incessu zomby. </p>
                                            <p> The voodoo sacerdos flesh eater, suscitat mortuos comedere carnem virus. Zonbi tattered for solum oculi eorum defunctis go lum cerebro. Nescio brains an Undead zombies. Sicut malus putrid voodoo horror. Nigh tofth eliv ingdead. </p> */}

                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}}>Subscription Title</th>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}} >Package</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Day</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Expire Date</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    { 
                                                    user_subscription_Details && user_subscription_Details.map( 
                                                        ( item, key) => 
                                                        
                                                            <tr key={key}>
                                                            <td style={{color:'white'}}>{item.subscription_name}</td>
                                                            <td style={{color:'white'}}>{item.subscription_price}</td>
                                                            <td style={{color:'white'}}>{item.validitydays} Day</td>
                                                            <td style={{color:'white'}}>{
                                                                
                                                            
                                                         // `${item.valid_datetime.getDate()}  ${months[item.valid_datetime.getMonth()]}  ${item.valid_datetime.getFullYear()}`
                                                         `${new Date(item.valid_datetime).getDate()}  ${months[new Date(item.valid_datetime).getMonth()]}  ${new Date(item.valid_datetime).getFullYear()}`
                                                          } </td>
                                                           
                                                        </tr>

                                                       )                                            
                                                    }
                                                   

                                                </tbody>
                                            </Table>

                                     {user_subscription_Details.length ?        <ReactPaginate
                                                previousLabel={"prev"}
                                                nextLabel={"next"}
                                                breakLabel={"..."}
                                                breakClassName={"break-me"}
                                                pageCount={this.state.pageCount}
                                                marginPagesDisplayed={2}
                                                pageRangeDisplayed={5}
                                                onPageChange={this.handlePageClick}
                                                containerClassName={"pagination"}
                                                subContainerClassName={"pages pagination"}
                                                activeClassName={"active"} />
                                                : ''
                                        }


                                    
                                            <div className="panel-heading">
                                                <h3 className="panel-title">Subscription Log </h3>
                                            </div>
                                            {/* <p> Zombie ipsum reversus ab viral inferno, nam rick grimes malum cerebro. De carne lumbering animata corpora quaeritis. Summus brains sit, morbo vel maleficia? De apocalypsi gorger omero undead survivor dictum mauris. Hi mindless mortuis soulless creaturas, imo evil stalking monstra adventus resi dentevil vultus comedat cerebella viventium. Qui animated corpse, cricket bat max brucks terribilem incessu zomby. </p>
                                            <p> The voodoo sacerdos flesh eater, suscitat mortuos comedere carnem virus. Zonbi tattered for solum oculi eorum defunctis go lum cerebro. Nescio brains an Undead zombies. Sicut malus putrid voodoo horror. Nigh tofth eliv ingdead. </p> */}

                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}}>Subscription Title</th>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}} >Package</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Day</th>
                                                        <th  style={{color:'white' , backgroundColor:'#a33cda'}} >Expire Date</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    { 
                                                    current_subscription_list && current_subscription_list.map( 
                                                        ( current_sub, index) => 
                                                        
                                                            <tr key={current_sub.transactionId}>
                                                            <td style={{color:'white'}}>{current_sub.subscription_name}</td>
                                                            <td style={{color:'white'}}>{current_sub.subscription_price}</td>
                                                            <td style={{color:'white'}}>{current_sub.validitydays} Day</td>
                                                            <td style={{color:'white'}}>{
                                                            `${new Date(current_sub.valid_datetime).getDate()}  ${months[new Date(current_sub.valid_datetime).getMonth()]}  ${new Date(current_sub.valid_datetime).getFullYear()}`
                                                            
                                                            } </td>
                                                           
                                                        </tr>

                                                       )                                            
                                                    }
                                                   

                                                </tbody>
                                            </Table>




                                        </div>
                                        <div role="tabpanel" className="tab-pane" id="tab3">
                                            {/* <p> Lorem ipsizzle dolor away amizzle, consectetuer pizzle elizzle. Nullizzle yo velizzle, check it out volutpizzle, quis, gravida vel, yo. Ma nizzle eget tortor. Sizzle eros. My shizz izzle dolizzle gizzle turpis tempizzle fo shizzle mah nizzle fo rizzle, mah home g-dizzle. Maurizzle pellentesque nibh izzle own yo'. Check it out in tortor. Pellentesque fizzle rhoncizzle nisi. </p>
                                            <p> In hac habitasse platea dictumst. Shizzlin dizzle dapibus. You son of a bizzle tellizzle urna, pretizzle fo shizzle mah nizzle fo rizzle, mah home g-dizzle, ghetto ac, check it out vitae, nunc. Shizzlin dizzle suscipizzle. Integizzle sempizzle velit sizzle dizzle. </p> */}
                                        
                                        <div className="panel-heading">
                                                <h3 className="panel-title">Favourits Video List</h3>
                                            </div>
                                        <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}}>Video Title</th>
                                                        {/* <th style={{color:'white' , backgroundColor:'#a33cda'}} >Image</th> */}
                                                        
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    { 
                                                    user_favourits_video_Details && user_favourits_video_Details.map( 
                                                        ( item, key) => 
                                                        
                                                            <tr key={key}>
                                                            <td  onClick={()=>this.video_details_page(item.videoid)} style={{color:'white'}}>{item.video}</td>
                                                            {/* <td style={{color:'white'}}>{item.image}</td> */}
                                                           
                                                           
                                                        </tr>

                                                       )                                            
                                                    }
                                                   

                                                </tbody>
                                            </Table>
                                        </div>

                                        <div role="tabpanel" className="tab-pane" id="tab4">
                                            {/* <p> Lorem ipsizzle dolor away amizzle, consectetuer pizzle elizzle. Nullizzle yo velizzle, check it out volutpizzle, quis, gravida vel, yo. Ma nizzle eget tortor. Sizzle eros. My shizz izzle dolizzle gizzle turpis tempizzle fo shizzle mah nizzle fo rizzle, mah home g-dizzle. Maurizzle pellentesque nibh izzle own yo'. Check it out in tortor. Pellentesque fizzle rhoncizzle nisi. </p>
                                            <p> In hac habitasse platea dictumst. Shizzlin dizzle dapibus. You son of a bizzle tellizzle urna, pretizzle fo shizzle mah nizzle fo rizzle, mah home g-dizzle, ghetto ac, check it out vitae, nunc. Shizzlin dizzle suscipizzle. Integizzle sempizzle velit sizzle dizzle. </p> */}
                                        
                                        <div className="panel-heading">
                                                <h3 className="panel-title">Watchlist Video List</h3>
                                            </div>
                                        <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th style={{color:'white' , backgroundColor:'#a33cda'}}>Video Title</th>
                                                        {/* <th style={{color:'white' , backgroundColor:'#a33cda'}} >Image</th> */}
                                                        
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    { 
                                                    user_watchlist_video_Details && user_watchlist_video_Details.map( 
                                                        ( item, key) => 
                                                        
                                                            <tr key={key}>
                                                            <td  onClick={()=>this.video_details_page(item.videoid)} style={{color:'white'}}>{item.video}</td>
                                                            {/* <td style={{color:'white'}}>{item.image}</td> */}
                                                           
                                                           
                                                        </tr>

                                                       )                                            
                                                    }
                                                   

                                                </tbody>
                                            </Table>
                                        </div>


                                        <div role="tabpanel" className="tab-pane" id="tab5">
                                            {/* <p> Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI. </p>
                                            <p> Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions. </p>
                                            <p> Completely synergize resource sucking relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. Dynamically innovate resource-leveling customer service for state of the art customer service. </p> */}

                                            <div className="panel-heading">
                                                <h3 className="panel-title">Change Password</h3>
                                            </div>
                                            <form method="post">
                                                <fieldset>

                                                    <div className={'input-name' + (password_submitted && !old_password ? ' has-error' : '')} >
                                                        <input type="password" value={old_password || ''} onChange={e => this.handleChange(e)} name="old_password" placeholder="Old Password" />
                                                        <span className="underline-animation"></span>
                                                    </div>
                                                    <br />
                                                    <div className={'input-name' + (password_submitted && !new_password ? ' has-error' : '')} >
                                                        <input type="password" value={new_password || ''} onChange={e => this.handleChange(e)} name="new_password" placeholder="New Password" />
                                                        <span className="underline-animation"></span>
                                                    </div>

                                                    {/* <div  className={'input-name' + (password_submitted && !new_password ? ' has-error' : '')} >
                                                    <input type="text" value={new_password}  onChange={e => this.handleChange(e)} name="new_password" placeholder="New Password"  />
                                                    <span className="underline-animation"></span>
                                                </div> */}
                                                    <input onClick={(e) => this.onpassword_Submit(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Update" />
                                                </fieldset>
                                            </form>
                                            {/* <div className="line-form"><ToastContainer /></div> */}
                                            <div className="line-form"><ToastContainer /></div>

                                        </div>
                                    </div>
                                </Col>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}



export default Profile