import React, { Component }  from 'react';
import {Helmet} from "react-helmet";
import * as utility from "../../utils/Utility";
import * as strings from "../../utils/Strings";
import { Link } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import {loginAPI} from '../../utils/Constants';
import { withRouter } from 'react-router-dom';
import FacebookLogin from 'react-facebook-login';
import { GoogleLogin } from 'react-google-login';

import { connect } from 'react-redux';

 class LoginForm extends Component{
    constructor(props) {
        super(props)
        this.state = {
            email       :   '',
            password    :   '',

            facebookuserID:'',
            facebookname:'',
            facebookemail:'',
            facebookpicture:'',
            facebookphone:'',

            googlename:'',
            googleemail:'',
            googlepicture:''

        };
    }
    initialState = () => {
        this.setState({
        email       :   '',
        password    :   '',
        submitted   :   false
        })
    }
    handleChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }
    onSubmit = (e) => {
        e.preventDefault();
        this.setState({ submitted: true });
        if(!this.state.email && !this.state.password){
            utility.showError("Please Enter Email or Phone & Password");
            return false;
        }
        if(!this.state.email){
            utility.showError("Please Enter Email or Phone");
            return false;
        }
        if(!this.state.password){
            utility.showError("Please Enter Password");
            return false;
        }
        const axios     =   require('axios');
        const FormData  =   require('form-data');
        const data      =   new FormData();

        data.append('username', this.state.email);
        data.append('password', this.state.password);

        var config  =   {
            method  :   'post',
            url     :   loginAPI,
            headers :   {
                'Content-Type': 'application/json'
            },
            data : data
        };

        axios(config)
            .then(function (response){
            console.log(JSON.stringify(response.data));
            //console.log((response.data));
            if(response.data.status === 'success'){

                this.props.dispatch({
                    type: 'FETCH_LOGIN_SUCCESS',
                    payload:  response 
                  });


                this.initialState();
                utility.showSuccess(response.data.message);
                localStorage.setItem('user_authenticationid', response.data.userdata.user_id);
                localStorage.setItem('country_code', response.data.userdata.country_code);
                localStorage.setItem('dob', response.data.userdata.dob);

                this.props.history.push(`/dashboard`);
            }
            else if(response.data.status === 'warning'){
                utility.showWarning(response.data.message); 
            }
            else{
                utility.showError(response.data.message); 
            }            
        }.bind(this))
            .catch(function (error){
            console.log(error);
        });
        
    }


    responseFacebook = (response) => {
        console.log(response);

        this.setState({
            facebookuserID:response.userID,
            facebookname:response.name,
            facebookemail:response.email,
            facebookphone:response.phone,
            facebookpicture:response.picture.data.url
            })
      }

    responseGoogle = (response) => {
        console.log(response);
        console.log(response.profileObj.imageUrl);

        this.setState({
           // googleuserID:response.userID,
            googlename:response.profileObj.name,
            googleemail:response.profileObj.email,
          //  googlephone:response.phone,
            googlepicture:response.profileObj.imageUrl
            })


      }



      componentClicked = () => {
        console.log('Clicked');
      }


    render() {
    const { email, password, submitted } = this.state;
    return (
        <div className="contain-area">
            <Helmet>
                <title>Login | {strings.stringsLocalContainer.SITE_TITLE}</title>
            </Helmet>
	        <div className="container">
		        <div className="row">
			        <div className="col-md-4"></div>
			            <div className="col-md-4">
				            <div className="panel panel-default login-area1">
					            <div className="panel-heading">
						            <h3 className="panel-title">Login</h3>
					            </div>
					            <div className="panel-body">
						        <form method="post">
							        <fieldset>
								    <div className={'form-group' + (submitted && !email ? ' has-error' : '')}>
									    <input value={email} className="form-control" placeholder="Mobile / Email Address" name="email" type="text" onChange={e => this.handleChange(e)} required />
									</div>
									<div className={'form-group' + (submitted && !password ? ' has-error' : '')}>
										<input value={password} className="form-control" placeholder="Password" name="password" type="password" onChange={e => this.handleChange(e)} required />
                                    </div>
                                    <div className="checkbox1">
                                        <label> Don't have an account? <Link to="/register">Create one</Link> </label>
                                    </div>
                                    <input onClick={(e) => this.onSubmit(e)} className="btn btn-lg btn-success btn-block" type="submit" value="Submit" />
                                    <div className="checkbox1"> 
                                        <label> <Link to="/forgotpassword">Forget Password ?</Link> </label>
                                    </div>
                                    </fieldset>
                                </form>
                                <div className="line-form"><ToastContainer /></div>
                                <center>
                                    <h4>Or</h4>
                                </center>
                                <div className="login-with">Login With</div>
                                <div className="social-logo">
                                    <Link to="/">
                                        <img src={require('../../assets/images/g-logo.png')} alt="google" />
                                    </Link>
                                    {/* <Link to="/">
                                        <img src={require('../../assets/images/f-logo.png')} alt="facebook" />
                                    </Link> */}

                                         
                                    <FacebookLogin
                                      appId="947498789083852"
                                      autoLoad={false}
                                      fields="name,email,picture"
                                      onClick={this.componentClicked}
                                      callback={this.responseFacebook} />

                                    <GoogleLogin
                                      clientId="270984297857-p82jsv292issqsaqfl23892guthjk2gp.apps.googleusercontent.com"
                                      buttonText="Login"
                                      onSuccess={this.responseGoogle}
                                      onFailure={this.responseGoogle}
                                      cookiePolicy={'single_host_origin'}  />

                               <div style={{color:"white"}}> {this.state.googlename}</div>
                               <div style={{color:"white"}}> {this.state.googleemail}</div>
                               <div style={{color:"white"}}> {this.state.googlepicture}</div>


                                      

                                <div style={{color:"white"}}> {this.state.facebookuserID}</div>
                                <div style={{color:"white"}}> {this.state.facebookname}</div>
                                <div style={{color:"white"}}> {this.state.facebookemail} </div>
                                <div style={{color:"white"}}> { this.state.facebookphone}</div>
                                <div style={{color:"white"}}> { this.state.facebookpicture}</div>
                                

                                


                                </div>
                            </div>
                        </div>
                    </div>
                <div className="col-md-4"></div>
            </div>
        </div>
    </div>
    );
  }
}

const mapStateToProps = state => ({
    authenticationid: state
   
  
  });
  
  export default connect(mapStateToProps)(withRouter(LoginForm));